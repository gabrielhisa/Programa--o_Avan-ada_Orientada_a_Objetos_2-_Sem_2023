package com.estudante.estudante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudanteApplicationTests {

	@Test
	void contextLoads() {
	}

}
